0.4 2013-01-27
==============

* added field remove parameter
* added vacuum parameter

0.3 2013-01-15
==============

* load log types from config

0.2 2013-01-14
==============

* automatic formatting
* status messages on debug
* keep order of fields

0.1 2013-01-13
==============

* initial checkout with basic functionality
